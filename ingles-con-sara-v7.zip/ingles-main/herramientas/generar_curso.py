#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genera lecciones/leccion-01..10.json de INGLÉS CON SARA con la misma fórmula:
gancho -> repaso -> escucha -> piezas con repetición -> errores -> juego -> conversación -> resumen/tarea/siguiente."""
import json, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE.parent))
import curso_datos
SERIE = sys.argv[1] if len(sys.argv) > 1 else "bloque1"
if SERIE == "oraciones":
    from curso_oraciones import L
else:
    from curso_datos import L
import crear_video as cv

CANAL = "INGLÉS CON SARA"
OBJ_MIN, OBJ_MAX = 8 * 60 + 15, 8 * 60 + 50     # segundos estimados objetivo

def d(t, **k): return {"d": t, **k}
def en(e, es, pr, **k): return {"en": e, "es": es, "pron": pr, **k}
COMPACTO = False
SIN_TIPS = False
R2MAX = None
JUEGO_N = 5
def seg(e, ronda):
    n = len(e.split()); s = 3 if n <= 2 else 4 if n <= 4 else 5 if n <= 6 else 6
    if ronda == 2: s = 3 if COMPACTO else s - (1 if s > 3 else 0)
    elif COMPACTO and s > 4: s -= 1
    return s
def tab(items): return [{"t": t, "e": e} for t, e in items]
def esc(cap, kick, tablero, pasos, **x): return dict(capitulo=cap, kicker=kick, tablero=tab(tablero), pasos=pasos, **x)
def reto(es, e, pr, s=4): return {"reto": {"p": "«" + es + "»", "r": e, "es": es, "pron": pr, "seg": s}}

CONN = ["Otra vez, repite conmigo. Más rápido.", "Una vez más, para que se te quede en la cabeza.", "Ahora en otro orden, para que no sea de memoria.",
        "Repite conmigo otra vez. Repetir es como se aprende.", "Última vuelta de este paso. Tú puedes."]

def pieza(i, pz):
    fr = pz["frases"]; pasos = [d(x) for x in pz["intro"]]
    for k, (e, es, pr) in enumerate(fr): pasos.append(en(e, es, pr, repite=seg(e, 1), **({"lento": True} if k == 0 and len(e.split()) >= 4 else {})))
    pasos.append(d(CONN[i % len(CONN)]))
    for e, es, pr in list(reversed(fr))[:R2MAX]: pasos.append(en(e, es, pr, repite=seg(e, 2)))
    if pz.get("tip") and not SIN_TIPS: pasos.append(d(pz["tip"]))
    return esc(pz["cap"], pz["kick"], [(pz["tab"][0], "grande"), (pz["tab"][1], "medio")], pasos)

def leccion(le, prev, extras):
    n = le["n"]; sc = []
    hook = [d(x) for x in le["hook"]]
    sc.append(esc("Empezamos", f"LECCIÓN {n} · {CANAL}", [(f"LECCIÓN {n}", "nota"), (le["grande"].upper(), "grande"), (le["chico"].capitalize(), "medio")], hook))
    if prev:
        pasos = [d("Antes de empezar, un repaso relámpago de la lección anterior. Piensa la respuesta antes de que aparezca.")]
        pasos += [reto(es, e, pr, 4) for es, e, pr in prev["juego"][:3]]
        sc.append(esc("Repaso relámpago", "REPASO RELÁMPAGO", [("Repaso relámpago", "grande"), ("Lo de la lección anterior", "nota")], pasos))
    pasos = [d(le["dlg_intro"])] + [en(e, es, pr, quien=q) for q, e, es, pr in le["dlg"]] + [d(le["dlg_outro"], tablero=tab([("Pieza por pieza", "grande"), ("Al final hablarás tú", "nota")]))]
    sc.append(esc("Escucha primero", "ESCUCHA ESTA CONVERSACIÓN", [("Una conversación real", "grande"), ("Primero escucha, sin traducir", "nota")], pasos, traduccion="despues"))
    for i, pz in enumerate(le["piezas"]):
        s = pieza(i, pz)
        if i == 1: s["pasos"].append(d("Si esta lección te está ayudando, dale like y suscríbete a Inglés con Sara. Es gratis y me ayuda un montón. Seguimos.", cta=True))
        sc.append(s)
    if "dialogo2" in extras:
        pasos = [d("Vamos a escuchar otra vez la conversación del principio. Ahora sí con la traducción y entendiéndola toda.")] + [en(e, es, pr, quien=q) for q, e, es, pr in le["dlg"]]
        sc.append(esc("La conversación otra vez", "LA CONVERSACIÓN OTRA VEZ", [("Ahora sí la entiendes", "grande"), ("Escúchala con la traducción", "nota")], pasos))
    er = [d("Tres errores que casi todos cometen. Presta atención, porque aquí se gana la buena pronunciación.", tablero=tab([("3 errores comunes", "grande"), ("Evítalos y sonarás mejor", "nota")]))]
    for malo, bueno, ex in le["errores"]: er.append(d(ex, tablero=tab([(malo, "malo"), (bueno, "bueno")])))
    sc.append(esc("Errores comunes", "ERRORES COMUNES", [("Errores comunes", "grande"), ("Evítalos y sonarás mejor", "nota")], er))
    ju = [d("Juego rápido. Te muestro una frase en español y tú la dices en inglés antes de que aparezca la respuesta.")] + [reto(es, e, pr, 3) for es, e, pr in le["juego"][:JUEGO_N]]
    sc.append(esc("Juego rápido", "JUEGO RÁPIDO", [("¿Cómo se dice?", "grande"), ("Piensa rápido", "nota")], ju))
    if "relampago" in extras:
        mix = [(es, e, pr) for pz in le["piezas"] for e, es, pr in pz["frases"][:1]]
        pasos = [d("Ronda relámpago. Ahora con frases de toda la lección. Si dudas, no pasa nada: la respuesta aparece enseguida.")] + [reto(es, e, pr, 3) for e, es, pr in [(m[1], m[0], m[2]) for m in mix]][:5]
        sc.append(esc("Ronda relámpago", "RONDA RELÁMPAGO", [("Ronda relámpago", "grande"), ("Toda la lección", "nota")], pasos))
    rl = le.get("conv_role", "Leo")
    pasos = [d(f"Última prueba. {rl} habla, y tú respondes en voz alta.")]
    for e, es, pr, hint in le["conv"]: pasos += [en(e, es, pr, quien=rl), {"pausa": 5 if len(hint) > 24 else 4, "texto": hint}]
    pasos += [d(le["solo"], tablero=tab(le["solo_tab"])), {"pausa": 12, "texto": "AHORA TÚ · SIN AYUDA"}]
    sc.append(esc("Tu conversación", "AHORA ERES TÚ", [("Tu turno", "grande"), (f"{rl} habla. Tú respondes.", "nota")], pasos))
    sc.append(esc("Resumen y tarea", "RESUMEN Y TAREA", [("Ya sabes decir", "grande"), ("Lo que aprendiste hoy", "medio")],
        [d(le["resumen"]), d(le["tarea"], tablero=tab([("TAREA", "grande"), ("Grábate y escucha", "medio")])), d(le["teaser"], cta=True, tablero=tab([("¡SUSCRÍBETE!", "grande"), (f"Lección {n + 1} · muy pronto", "nota"), (CANAL, "medio")]))]))
    return dict(numero=n, canal=CANAL, titulo=le["titulo"], minimo_minutos=8, maximo_minutos=9, ritmo_voz=2.6,
                miniatura={"grande": le["grande"], "chico": le["chico"]}, descripcion=le["desc"] + f"\n\n{CANAL} · Curso de inglés práctico para hispanohablantes. Lección {n} de 50.",
                hashtags="#inglés #aprenderinglés #inglesconsara #inglésparahispanohablantes #cursodeinglés", escenas=sc)

def estimado(j): return cv.Builder(j).build().t_end

if __name__ == "__main__":
    out = HERE.parent / "lecciones"; out.mkdir(exist_ok=True)
    prev = curso_datos.L[-1] if SERIE == "oraciones" else None
    for le in L:
        elegido = None
        niveles = [(False, False, None, 5, []), (False, False, None, 5, ["relampago"]), (False, False, None, 5, ["dialogo2"]), (False, False, None, 5, ["relampago", "dialogo2"]),
                   (True, False, None, 5, []), (True, True, None, 5, []), (True, True, 3, 5, []), (True, True, 2, 5, []), (True, True, 2, 4, []), (True, True, 1, 4, []), (True, True, 1, 3, [])]
        for comp, tips, r2, jn, extras in niveles:
            globals().update(COMPACTO=comp, SIN_TIPS=tips, R2MAX=r2, JUEGO_N=jn)
            j = leccion(le, prev, extras); t = estimado(j)
            if OBJ_MIN <= t <= OBJ_MAX: elegido = (j, t, extras); break
            if elegido is None or abs(t - 515) < abs(elegido[1] - 515): elegido = (j, t, extras)
        j, t, extras = elegido
        (out / f"leccion-{le['n']:02d}.json").write_text(json.dumps(j, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"Lección {le['n']:2d}: {int(t//60)}:{int(t%60):02d} estimado  extras={extras}  {le['titulo'][:50]}")
        prev = le
