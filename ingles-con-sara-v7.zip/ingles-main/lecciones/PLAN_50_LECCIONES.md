# Plan del curso · 50 lecciones (inglés práctico para hispanohablantes)

Cada lección dura 8–9 min y sigue la misma fórmula que engancha:
**gancho → escucha primero → piezas con práctica → errores comunes → juego rápido → conversación → resumen + tarea + gancho de la siguiente.**

## Bloque 1 · Supervivencia (1–10)
1. Preséntate (saludar, nombre, país, cómo estás) ✅ hecha
2. Números 0–100: edad, teléfono, precios («I'm 20», no «I have 20 years»)
3. Verbo TO BE completo (I am / you are / he is…) con frases que usarás hoy
4. Preguntas básicas: What, Where, Who, When, Why, How
5. En el aeropuerto y migración
6. Pedir comida en un restaurante
7. Pedir y entender direcciones
8. De compras: How much?, tallas, probarse ropa
9. La hora y el clima
10. Días, meses, fechas y planes de la semana

## Bloque 2 · Tu día a día (11–20)
11. Mi familia (his/her/their)
12. Mi casa y mis cosas (There is / There are)
13. Rutina diaria (presente simple: yo)
14. Rutina diaria (he / she / it: la «s» que todos olvidan)
15. Comida y bebida: gustos (I like / I love / I hate)
16. WANT, NEED y HAVE: pedir lo que necesitas
17. CAN: lo que sabes y puedes hacer
18. Ropa, colores y descripciones
19. Cuerpo y salud: ir al doctor y a la farmacia
20. Transporte: bus, taxi, Uber, tren

## Bloque 3 · Conversar con confianza (21–30)
21. Preguntas con DO / DOES
22. Pedir cosas con educación (Could you…? Can I…? Would you…?)
23. Ahora mismo: presente continuo (I'm working, I'm eating)
24. Pasado simple 1: verbos regulares (ayer, la semana pasada)
25. Pasado simple 2: verbos irregulares más usados
26. Contar lo que hiciste el fin de semana
27. Futuro: going to y will
28. Comparar: bigger, better, more expensive
29. Frecuencia: always, usually, never
30. Small talk: hablar de cualquier cosa con un extraño

## Bloque 4 · Vida real (31–40)
31. Hotel y viajes: reservar, quejarse, pedir ayuda
32. Entrevista de trabajo 1: hablar de ti
33. Entrevista de trabajo 2: experiencia y habilidades
34. Vocabulario de oficina y reuniones
35. Escribir mensajes y correos cortos
36. Hablar por teléfono (y entender lo que dicen rápido)
37. Emergencias y problemas: «Help», «I lost…», «I need a doctor»
38. Hobbies, deportes y tiempo libre
39. Opiniones: I think, I agree, I disagree
40. Invitar, aceptar y rechazar planes

## Bloque 5 · Sonar natural (41–50)
41. Present perfect: «I have been…» (experiencias)
42. If… (condicionales 0 y 1)
43. Should, must, have to: consejos y obligaciones
44. Phrasal verbs que sí se usan (1)
45. Phrasal verbs que sí se usan (2)
46. Slang y expresiones del día a día
47. Pronunciación: TH, R, vocales difíciles
48. Pronunciación: conectar palabras como un nativo
49. Contar una historia en inglés
50. Gran final: reto de 50 frases + tu presentación de nivel 2
